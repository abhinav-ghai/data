function Get-MyCmdlet{
Write-Output "Get-MyCmdlet ran."
}